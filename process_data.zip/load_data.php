#!/usr/local/bin/php
<?php
 // config vars
 $cfg_data_dir = "./data/";

 $cfg_db_host = "localhost";
 $cfg_db_user = "sample_user";
 $cfg_db_password = "any_valid_pass";
 $cfg_db_database = "stores";
 $cfg_db_encoding = "utf8";




 // connect to database
 $sql = mysqli_init();
 @$sql->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, 1);

 @$sql->real_connect($cfg_db_host, $cfg_db_user, $cfg_db_password, $cfg_db_database);

 if ($sql->connect_errno)
  exit("Ошибка: невозможно подсоединиться к базе данных. Сообщение сервера: " . $sql->connect_error);

 $sql->set_charset($cfg_db_encoding);




 // parse data
 $products = array();
 $offers = array();

 foreach (glob($cfg_data_dir . "import*") as $file)
 {
  echo $file . "\n";



  if // load data
  (
   !($import_dom = simplexml_load_file($file))
   ||
   !($offers_dom = simplexml_load_file(str_replace("import", "offers", $file)))
  )
   continue; // in a case of any errors skip to next city (file)



  //parse import
  $city = strval($import_dom->Каталог->Наименование);

  foreach ($import_dom->Каталог->Товары->Товар as $product)
  {
   $code = strval($product->Код);

   if (empty($products[$code]))
   {
    $products[$code] = array();

    $products[$code]["name"] = $product->Наименование;
    $products[$code]["weight"] = $product->Вес;

    if (!empty($product->Взаимозаменяемости))
    {
     foreach ($product->Взаимозаменяемости->Взаимозаменяемость as $analog)
      $products[$code]["analog"] .= $analog->Марка . "-" . $analog->Модель . "-" . $analog->КатегорияТС . "|";

     $products[$code]["analog"] = rtrim($products[$code]["analog"], "|");
    }
   }
  }



  //parse offers
  foreach ($offers_dom->ПакетПредложений->Предложения->Предложение as $offer)
  {
   $code = strval($offer->Код);

   if (empty($offers[$code]))
   {
    $offers[$code] = array();

    $offers[$code][strval($city)]["quantity"] = $offer->Количество;

    foreach ($offer->Цены->Цена as $price) // get the first price
    {
	 $offers[$code][$city]["price"] = $price->ЦенаЗаЕдиницу;
	 break;
	}
   }
  }



 } // end of files parsing




 // save products to database
 foreach ($products as $code=>$product)
 {
  $res = $sql->query("SELECT id FROM products WHERE code='" . addslashes($code) . "'");

  if ($res->num_rows > 0) // update
  {
   $quantity = "";
   $price = "";

   if (!empty($offers[$code]))
    foreach ($offers[$code] as $city=>$vals)
    {
     $quantity .= ", quantity_" . $city . "=" . intval($vals["quantity"]);
     $price .= ", price_" . $city . "=" . floatval($vals["price"]);
    }

   $sql->query("UPDATE products SET name='" . addslashes($product["name"]) . "', weight=" . floatval($product["weight"]) .
    ", usage='" . addslashes($product["analog"]) . "'" . $quantity . $price . " WHERE code='" . addslashes($code) . "'");
  }
  else // insert
  {
   $sqlquery = "INSERT INTO products (name, code, weight, usage";

   if (!empty($offers[$code]))
    foreach ($offers[$code] as $city=>$vals)
    {
     $sqlquery .= ", quantity_" . $city;
     $sqlquery .= ", price_" . $city;
    }

   $sqlquery .= ") VALUES('" . addslashes($product["name"]) . "', '" . addslashes($code) . "', " .
    floatval($product["weight"]) . ", '" . addslashes($product["analog"]) . "'";

   if (!empty($offers[$code]))
    foreach ($offers[$code] as $city=>$vals)
    {
     $sqlquery .= ", " . intval($vals["quantity"]);
     $sqlquery .= ", " . floatval($vals["price"]);
    }

   $sqlquery .= ")";

   $sql->query($sqlquery);
  }
 }

 $sql->close();
?>