<?php
 // config vars
 $cfg_products_per_page = 50;

 $cfg_db_host = "localhost";
 $cfg_db_user = "sample_user";
 $cfg_db_password = "any_valid_pass";
 $cfg_db_database = "stores";
 $cfg_db_encoding = "utf8";




 /*!
  @function get_pages_menu
  @abstract Get paginator menu as list of HTML-links to other pages.
  @param num_items int - total number of items
  @param num_items_per_page int - number of items per page
  @param current_page_num int - number of the current page
  @param items_name string - name of items
  @param items_wordend string - end of word for cases when items belongs to "he", "she" or "it" (in russian)
  @result string - pages menu
 */
 function get_pages_menu($num_items, $num_items_per_page = 50, $current_page_num = 0, $items_name = "записей", $items_wordend = "а")
 {
  $pages_menu = "";
  $first = 0;
  $last = $num_items;

  if ($num_items > $num_items_per_page)
  {
   $pages_count = ceil(floatval($num_items) / $num_items_per_page);

   $_SESSION["rtv_products_p"] = $page_num = min
   (
    (((empty($current_page_num) && ($current_page_num != "0")) || !is_numeric($current_page_num) || ($current_page_num < 0)) ?
	((!empty($_SESSION["rtv_products_p"])) ? ($_SESSION["rtv_products_p"]) : 0) : $current_page_num), ($pages_count - 1)
   );

   $first = $page_num * $num_items_per_page;
   $last = min($num_items, $first + $num_items_per_page);

   $pages_menu = " Страницы: ";

   if ($page_num > 9)
	$pages_menu .= "<A HREF=\"" . $_SERVER["PHP_SELF"] . "?p=0\">&lt;&lt;</A>\n";

   $first_page = floor($page_num / 10) * 10;
   $last_page = min($first_page + 10, $pages_count);

   $pages_menu .= ((($first_page - 1) > 0) ? ("<A HREF=\"" . $_SERVER["PHP_SELF"] .
	"?p=" . ($first_page - 1) . "\">&lt;</A>\n") : "");

   for ($i = $first_page; $i < $last_page; ++$i)
	$pages_menu .= (($page_num == $i) ? ("<B>" . ($i + 1) . "</B>\n") :
	 ("<A HREF=\"" . $_SERVER["PHP_SELF"] . "?p=" . $i . "\">" . ($i + 1) . "</A>\n"));

   $pages_menu .= (($last_page < $pages_count) ? ("<A HREF=\"" . $_SERVER["PHP_SELF"] .
	"?p=" . $last_page . "\">&gt;</A>\n") : "");

   if ($pages_count > 10)
	$pages_menu .= (($last_page < $pages_count) ? ("<A HREF=\"" . $_SERVER["PHP_SELF"] .
	 "?p=" . ($pages_count - 1) . "\">&gt;&gt;</A>\n") : "");
  }

  return "Всего " . $items_name . ": " . $num_items . ", " . ((($first + 1) == $last) ?
   ("показан" . $items_wordend . " " . $last) : ("показаны с " . ($first + 1) . " по " . $last)) . "." . $pages_menu;
 }




 // connect to database
 $sql = mysqli_init();
 @$sql->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, 1);

 @$sql->real_connect($cfg_db_host, $cfg_db_user, $cfg_db_password, $cfg_db_database);

 if ($sql->connect_errno)
  exit("Ошибка: невозможно подсоединиться к базе данных. Сообщение сервера: " . $sql->connect_error);

 $sql->set_charset($cfg_db_encoding);




 // show products list
 $sqlquery = "SELECT SQL_CALC_FOUND_ROWS * FROM products ORDER BY id DESC";

 $sqlquery .= " LIMIT " . addslashes(((empty($_REQUEST["p"]) || !is_numeric($_REQUEST["p"])) ?
   "0" : $_REQUEST["p"]) * $cfg_products_per_page) . "," . $cfg_products_per_page;

 // process query & get number of overall selected rows
 if
 (
  $sql->multi_query($sqlquery . "; SELECT FOUND_ROWS()")
  &&
  ($res = $sql->store_result())
  &&
  $sql->next_result()
  &&
  ($numres = $sql->store_result())
 )
 {
  $num_rows = $numres->fetch_row();
  $num_rows = $num_rows[0];
  $numres->free();
 }

 if ($num_rows > 0)
 {
  $pages_menu = get_pages_menu($num_rows, $cfg_products_per_page, empty($_REQUEST["p"]) ? "0" : $_REQUEST["p"], "записей", "");

  echo $pages_menu;
?>
<br /><br />
<table align=center width=100% border=0 cellpadding=3 cellspacing=2>
<tr><th align=left valign=middle>
ID
</th><th align=left valign=middle>
Код
</th><th align=left valign=middle>
Название
</th></tr>
<?
  while ($arr = $res->fetch_assoc())
  {
?>
<tr><td align=left valign=middle>
<?=$arr["id"]?>
</td><td align=left valign=middle>
<?=stripslashes($arr["code"])?>
</td><td align=left valign=middle>
<?=stripslashes($arr["name"])?>
</td></tr>
<?
  }

  $res->free();
?>
</table><br />
<?
  echo $pages_menu;
 }
 else
  echo "Записей не найдено.";

 $sql->close();
?>